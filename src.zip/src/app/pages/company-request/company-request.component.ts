import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'company-request',
  template: `<router-outlet></router-outlet>`,
})
export class CompanyRequestComponent implements OnInit {
    constructor(){}
    ngOnInit() {
    }
}



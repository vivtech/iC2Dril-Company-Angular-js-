import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-request-view-modal',
  templateUrl: './company-request-view-modal.component.html',
  styleUrls: ['./company-request-view-modal.component.css']
})
export class CompanyRequestViewModalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

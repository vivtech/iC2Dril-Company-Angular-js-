import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popover-option',
  templateUrl: './popover-option.component.html',
  styleUrls: ['./popover-option.component.css']
})
export class PopoverOptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

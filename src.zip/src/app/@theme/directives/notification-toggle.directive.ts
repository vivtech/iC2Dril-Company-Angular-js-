import { Directive } from '@angular/core';

@Directive({
  selector: '[appNotificationToggle]'
})
export class NotificationToggleDirective {

  constructor() { }

}

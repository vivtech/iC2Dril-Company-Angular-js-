export class User {
    _id?: number;
    name: string;
    email?: string;
    phone?: string;
    active?: string;
    designation?: string;
    userType?: string;
    blocked?: string;
}

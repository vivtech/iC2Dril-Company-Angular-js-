export interface Country {
    _id?: string;
    name: string;
    symbol?: string;
    code?: string;
    active?: number;
}

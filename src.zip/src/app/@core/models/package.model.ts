export interface Package {
    _id?: string;
    name: string;
    user: number;
    active?: number;
}

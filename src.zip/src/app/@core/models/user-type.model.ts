export class UserType {
    _id?: string;
    name: string;
    adminType?: number;
    mobileLogin?: number;
    active: number;
}
